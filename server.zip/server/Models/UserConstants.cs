﻿using Azure.Identity;
using Microsoft.AspNetCore.Identity;
using Microsoft.IdentityModel.Protocols;

namespace bookstore_backend.Models
{
    public class UserConstants
    {
        public static List<UserModel> Users = new()
        {
            new UserModel(){Username="Shiva",Password="admin",Role="Admin"}
        };
    }
}
