﻿namespace bookstore_backend.Models
{
    public class AuthResponse
    {
        public string Token { get; set; }  // JWT Token
        public string Message { get; set; } // Success/Failure message

        public bool Success { get; set; }
    }
}
