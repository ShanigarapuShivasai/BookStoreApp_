﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace bookstore_backend.Models
{
    public class WishlistBook
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required]
        public int UserId { get; set; }  // ✅ New column for associating a wishlist item with a user

        [Required]
        public int BookId { get; set; }

        public string Title { get; set; }
        public string Author { get; set; }
        public string Img { get; set; }
        public decimal Price { get; set; }
        public string Description { get; set; }
        public string Genre { get; set; }
        public string ISBN { get; set; }
    }
}
