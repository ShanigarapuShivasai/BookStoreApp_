﻿using bookstore_backend.Data;
using bookstore_backend.Models;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookStoreAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors("AllowAll")]
    public class BooksController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public BooksController(ApplicationDbContext context)
        {
            _context = context;
        }

        // ✅ GET: Get All Books
        [HttpGet]
        public async Task<IActionResult> GetAllBooks()
        {
            var books = await _context.Books.ToListAsync();
            return Ok(books);
        }

        // ✅ GET: Get Book by ID
        [HttpGet("{id}")]
        public async Task<IActionResult> GetBookById(int id)
        {
            var book = await _context.Books.FindAsync(id);
            if (book == null) return NotFound(new { message = "Book not found" });
            return Ok(book);
        }

        // ✅ POST: Add a New Book
        [HttpPost]
        public async Task<IActionResult> AddBook([FromBody] Book book)
        {
            if (book == null) return BadRequest(new { message = "Invalid book data" });

            // Check if ISBN already exists
            var existingBook = await _context.Books.FirstOrDefaultAsync(b => b.ISBN == book.ISBN);
            if (existingBook != null) return BadRequest(new { message = "ISBN already exists" });

            _context.Books.Add(book);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetBookById), new { id = book.Id }, book);
        }

        // ✅ PUT: Update an Existing Book
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateBook(int id, [FromBody] Book updatedBook)
        {
            var book = await _context.Books.FindAsync(id);
            if (book == null) return NotFound(new { message = "Book not found" });

            // Check if the new ISBN already exists in another book
            var existingBook = await _context.Books.FirstOrDefaultAsync(b => b.ISBN == updatedBook.ISBN && b.Id != id);
            if (existingBook != null) return BadRequest(new { message = "ISBN already exists for another book" });

            // ✅ Update book details
            book.Title = updatedBook.Title;
            book.Author = updatedBook.Author;
            book.Img = updatedBook.Img;
            book.Price = updatedBook.Price;
            book.Description = updatedBook.Description;
            book.Genre = updatedBook.Genre;
            book.ISBN = updatedBook.ISBN;

            await _context.SaveChangesAsync();
            return Ok(new { message = "Book updated successfully" });
        }

        // ✅ DELETE: Remove a Book
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteBook(int id)
        {
            var book = await _context.Books.FindAsync(id);
            if (book == null) return NotFound(new { message = "Book not found" });

            _context.Books.Remove(book);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Book deleted successfully" });
        }

        // ✅ GET: Get All Genres
        [HttpGet("genres")]
        public async Task<IActionResult> GetGenres()
        {
            var genres = await _context.Books.Select(b => b.Genre).Distinct().ToListAsync();
            return Ok(genres);
        }

        // ✅ GET: Search Books by Title, Author, Genre, or ISBN
        [HttpGet("search")]
        public async Task<IActionResult> SearchBooks([FromQuery] string query)
        {
            if (string.IsNullOrWhiteSpace(query))
                return BadRequest(new { message = "Search query cannot be empty" });

            var results = await _context.Books
                .Where(b =>
                    b.Title.Contains(query) ||
                    b.Author.Contains(query)||
                    b.Genre.Contains(query) ||
                    b.ISBN.Contains(query)) // Added ISBN search
                .ToListAsync();

            if (!results.Any())
                return NotFound(new { message = "No books found matching your search" });

            return Ok(results);
        }
    }
}
