import React, { createContext, useState } from "react";

export const CartContext = createContext();

export const CartProvider = ({ children }) => {
  const [cart, setCart] = useState([]);

  // Add Book to Cart (Prevents Duplicates)
  const addToCart = (book) => {
    setCart((prevCart) => {
      if (!prevCart.some((item) => item.id === book.id)) {
        return [...prevCart, book];
      }
      return prevCart;
    });
  };

  // Remove Book from Cart
  const removeFromCart = (id) => {
    setCart((prevCart) => prevCart.filter((item) => item.id !== id));
  };

  return (
    <CartContext.Provider value={{ cart, addToCart, removeFromCart }}>
      {children}
    </CartContext.Provider>
  );
};
