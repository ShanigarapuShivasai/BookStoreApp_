import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Button, Container, Typography, Paper, Box } from "@mui/material";

const DeleteBook = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [bookTitle, setBookTitle] = useState("");

  useEffect(() => {
    fetch(`https://localhost:7045/api/Books/${id}`)
      .then((res) => res.json())
      .then((data) => setBookTitle(data.title))
      .catch((error) => console.error("Error fetching book:", error));
  }, [id]);

  const handleDelete = () => {
    fetch(`https://localhost:7045/api/Books/${id}`, {
      method: "DELETE",
    })
      .then(() => {
        alert("Book deleted successfully!");
        navigate("/books");
      })
      .catch((error) => console.error("Error deleting book:", error));
  };

  return (
    <Container maxWidth="sm">
      <Paper elevation={3} sx={{ padding: 3, marginTop: 4, textAlign: "center" }}>
        <Typography variant="h5" gutterBottom>
          Delete Book
        </Typography>
        <Typography variant="body1" paragraph>
          Are you sure you want to delete the book <strong>{bookTitle}</strong>?
        </Typography>
        <Box display="flex" justifyContent="center" gap={2}>
          <Button variant="contained" color="error" onClick={handleDelete}>
            Yes, Delete
          </Button>
          <Button variant="outlined" color="primary" onClick={() => navigate("/books")}>
            Cancel
          </Button>
        </Box>
      </Paper>
    </Container>
  );
};

export default DeleteBook;
