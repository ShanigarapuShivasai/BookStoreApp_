import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { TextField, Button, Container, Typography, Paper, Box, Grid } from "@mui/material";

const EditBook = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [book, setBook] = useState({
    title: "",
    author: "",
    price: "",
    description: "",
    img: "",
    genre: "",
    isbn: "",
  });

  useEffect(() => {
    fetch(`https://localhost:5000/api/Books/${id}`)
      .then((res) => res.json())
      .then((data) => setBook(data))
      .catch((error) => console.error("Error fetching book:", error));
  }, [id]);

  const handleChange = (e) => {
    setBook({ ...book, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
  
    fetch(`https://localhost:7045/api/Books/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...book, id }),  // Ensure ID is included
    })
      .then((res) => {
        if (!res.ok) {
          return res.json().then((data) => {
            throw new Error(data.message || "Failed to update book");
          });
        }
        return res.json();
      })
      .then(() => {
        alert("Book updated successfully!");
        navigate("/books");
      })
      .catch((error) => {
        console.error("Error updating book:", error);
        alert(error.message);
      });
  };
  
  return (
    <Container maxWidth="sm">
      <Paper elevation={3} sx={{ padding: 3, marginTop: 4 }}>
        <Typography variant="h5" gutterBottom>
          Edit Book
        </Typography>
        <form onSubmit={handleSubmit}>
          <Grid container spacing={2}>
          <Grid item xs={12}>
              <TextField fullWidth label="Title" name="title" value={book.title} onChange={handleChange} required />
            </Grid>
            <Grid item xs={12}>
              <TextField fullWidth label="Author" name="author" value={book.author} onChange={handleChange} required />
            </Grid>
            <Grid item xs={12}>
              <TextField fullWidth type="number" label="Price" name="price" value={book.price} onChange={handleChange} required />
            </Grid>
            <Grid item xs={12}>
              <TextField fullWidth multiline rows={4} label="Description" name="description" value={book.description} onChange={handleChange} required />
            </Grid>
            <Grid item xs={12}>
              <TextField fullWidth label="Image URL" name="img" value={book.img} onChange={handleChange} required />
            </Grid>
            <Grid item xs={12}>
              <TextField fullWidth label="Genre" name="genre" value={book.genre} onChange={handleChange} required />
            </Grid>
            <Grid item xs={12}>
              <TextField fullWidth label="ISBN" name="isbn" value={book.isbn} onChange={handleChange} required />
            </Grid>
            <Grid item xs={12}>
              <Box display="flex" justifyContent="space-between">
                <Button type="submit" variant="contained" color="primary">
                  Update Book
                </Button>
                <Button variant="outlined" color="secondary" onClick={() => navigate("/books")}>
                  Cancel
                </Button>
              </Box>
            </Grid>
          </Grid>
        </form>
      </Paper>
    </Container>
  );
};

export default EditBook;
