import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button, Container, Paper, Typography } from "@mui/material";

const AdminDashboard = () => {
  const navigate = useNavigate();
  const handleLogout = () => {
    localStorage.removeItem("token"); // Clear token
    localStorage.removeItem("role"); // Clear role

    navigate("/auth"); // Redirect to login page
  };

  return (
    <Container maxWidth="sm">
      <Paper elevation={3} style={{ padding: "20px", marginTop: "50px", textAlign: "center" }}>
        <Typography variant="h4" gutterBottom>
          Admin Dashboard
        </Typography>

        <Button variant="contained" color="primary" style={{ margin: "10px" }} component={Link} to="/admin/add-book">
          Add Book
        </Button>

        <Button variant="contained" color="secondary" style={{ margin: "10px" }} component={Link} to="/admin/edit-book">
          Edit Book
        </Button>

        <Button variant="contained" color="error" style={{ margin: "10px" }} component={Link} to="/admin/delete-book">
          Delete Book
        </Button>

        <Button variant="outlined" color="error" style={{ marginTop: "20px" }} onClick={handleLogout}>
          Logout
        </Button>
      </Paper>
    </Container>
  );
};

export default AdminDashboard;
