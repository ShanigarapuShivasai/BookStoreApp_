import { useState } from "react";
import axios from "axios";
import { TextField, Button, Container, Typography, Paper, Box } from "@mui/material";

const AddBook = () => {
  const [book, setBook] = useState({
    title: "",
    author: "",
    img: "",
    price: "",
    description: "",
    genre: "",
    isbn: "",  // Added ISBN field
  });

  const handleChange = (e) => {
    setBook({ ...book, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post("https://localhost:7045/api/Books", book, {
        headers: { 
          "Content-Type": "application/json" 
        }, // Ensure credentials (cookies, headers) are sent
      });      
      alert("Book added successfully!");
      setBook({ title: "", author: "", img: "", price: "", description: "", genre: "", isbn: "" }); // Reset form
    } catch (error) {
      console.error("Error adding book:", error.response ? error.response.data : error.message);
      alert("Failed to add book. Please check the console for details.");
    }
  };

  return (
    <Container maxWidth="sm">
      <Paper elevation={3} sx={{ padding: 3, marginTop: 5, textAlign: "center" }}>
        <Typography variant="h5" gutterBottom>
          Add a New Book
        </Typography>
        <Box component="form" onSubmit={handleSubmit} sx={{ display: "flex", flexDirection: "column", gap: 2 }}>
          <TextField label="Title" name="title" value={book.title} onChange={handleChange} required fullWidth />
          <TextField label="Author" name="author" value={book.author} onChange={handleChange} required fullWidth />
          <TextField label="Image URL" name="img" value={book.img} onChange={handleChange} required fullWidth />
          <TextField
            label="Price"
            name="price"
            type="number"
            value={book.price}
            onChange={handleChange}
            required
            fullWidth
          />
          <TextField label="Description" name="description" value={book.description} onChange={handleChange} required fullWidth multiline rows={3} />
          <TextField label="Genre" name="genre" value={book.genre} onChange={handleChange} required fullWidth />
          <TextField label="ISBN" name="isbn" value={book.isbn} onChange={handleChange} required fullWidth /> {/* Added ISBN Input */}
          <Button type="submit" variant="contained" color="primary" fullWidth>
            Add Book
          </Button>
        </Box>
      </Paper>
    </Container>
  );
};

export default AddBook;
