import React from "react";
import { Container, Typography } from "@mui/material";

const NewArrivals = () => {
  return (
    <Container sx={{ marginTop: "20px" }}>
      <Typography variant="h4">New Arrivals</Typography>
      <Typography variant="body1">Check out the latest books in our collection.</Typography>
    </Container>
  );
};

export default NewArrivals;
