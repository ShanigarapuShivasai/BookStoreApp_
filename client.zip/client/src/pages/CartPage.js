import React, { useContext } from "react";
import { CartContext } from "../context/CartContext"; // Ensure the path is correct
import { Button, Typography, Card, CardContent, CardActions } from "@mui/material";

const CartPage = () => {
  const { cart, removeFromCart } = useContext(CartContext);

  return (
    <div style={{ padding: "20px" }}>
      <Typography variant="h4" gutterBottom>
        Shopping Cart
      </Typography>

      {cart.length === 0 ? (
        <Typography variant="h6">Your cart is empty.</Typography>
      ) : (
        cart.map((item) => (
          <Card key={item.id} sx={{ marginBottom: 2, maxWidth: 400 }}>
            <CardContent>
              <Typography variant="h6">{item.title}</Typography>
              <Typography variant="body1">Price: ₹{item.price}</Typography>
            </CardContent>
            <CardActions>
              <Button onClick={() => removeFromCart(item.id)} variant="contained" color="error">
                Remove
              </Button>
            </CardActions>
          </Card>
        ))
      )}
    </div>
  );
};

export default CartPage;
