import React, { useContext } from "react";
import { Container, Typography, Button, Card, CardContent, CardMedia, Grid } from "@mui/material";
import { CartContext } from "./CartContext"; // Ensure the path is correct

const Cart = () => {
  const { cart, removeFromCart } = useContext(CartContext);

  return (
    <Container>
      <Typography variant="h3" fontWeight="bold" textAlign="center">
        Cart
      </Typography>
      {cart.length === 0 ? (
        <Typography variant="h6" textAlign="center" sx={{ mt: 3 }}>
          Your cart is empty.
        </Typography>
      ) : (
        <Grid container spacing={3} sx={{ mt: 3 }}>
          {cart.map((book) => (
            <Grid item xs={12} sm={6} md={4} key={book.id}>
              <Card sx={{ height: 400, borderRadius: "12px", boxShadow: 4 }}>
                <CardMedia component="img" height="200" image={book.img} alt={book.title} />
                <CardContent sx={{ textAlign: "center" }}>
                  <Typography variant="h6" fontWeight="bold" color="#1a237e">
                    {book.title}
                  </Typography>
                  <Typography variant="h6" fontWeight="bold" color="#000">
                    Rs. {book.price}
                  </Typography>
                  <Button
                    onClick={() => removeFromCart(book.id)}
                    variant="contained"
                    sx={{
                      mt: 2,
                      backgroundColor: "red",
                      "&:hover": { backgroundColor: "darkred" },
                    }}
                  >
                    Remove from Cart
                  </Button>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>
      )}
    </Container>
  );
};

export default Cart;
