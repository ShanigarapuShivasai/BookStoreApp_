import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { Container, Typography, Card, CardMedia, CardContent, CircularProgress, Alert } from "@mui/material";

const BookDetails = () => {
  const { id } = useParams();
  const [book, setBook] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchBook = async () => {
      try {
        const response = await fetch(`https://localhost:7045/api/Books/${id}`);
        if (!response.ok) {
          throw new Error("Book not found");
        }
        const data = await response.json();
        setBook(data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchBook();
  }, [id]);

  if (loading) {
    return (
      <Container sx={{ marginTop: "20px", textAlign: "center" }}>
        <CircularProgress />
        <Typography variant="h6" sx={{ marginTop: "10px" }}>Loading Book Details...</Typography>
      </Container>
    );
  }

  if (error) {
    return (
      <Container sx={{ marginTop: "20px", textAlign: "center" }}>
        <Alert severity="error">{error}</Alert>
      </Container>
    );
  }

  return (
    <Container sx={{ marginTop: "20px", textAlign: "center" }}>
      <Typography variant="h3" gutterBottom fontWeight="bold" color="#2c3e50">{book.title}</Typography>
      <Typography variant="h5" color="textSecondary" fontStyle="italic">{book.author}</Typography>
      <Typography variant="h4" fontWeight="bold" sx={{ color: "#000", fontFamily: "serif", marginTop: "10px" }}>
        Rs. {book.price}
      </Typography>
      <Card sx={{ maxWidth: 500, margin: "20px auto", boxShadow: 4, borderRadius: "12px" }}>
        <CardMedia component="img" image={book.img} alt={book.title} />
        <CardContent>
          <Typography variant="body1" sx={{ marginTop: "10px", fontSize: "18px", lineHeight: "1.6", color: "#555" }}>
            {book.description}
          </Typography>
        </CardContent>
      </Card>
    </Container>
  );
};

export default BookDetails;
