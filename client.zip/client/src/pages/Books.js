import React, { useState, useEffect } from "react";
import { Favorite, FavoriteBorder } from "@mui/icons-material";
import { Container, Typography, Grid, Card, CardContent, CardMedia, IconButton, Box, Button, Checkbox, FormControlLabel, Slider, TextField, FormGroup } from "@mui/material";
import { Link } from "react-router-dom";

const Books = () => {
  const [books, setBooks] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");

  const [wishlist, setWishlist] = useState(new Set());
  const [selectedAuthors, setSelectedAuthors] = useState([]);
  const [selectedGenres, setSelectedGenres] = useState([]);
  const [priceRange, setPriceRange] = useState([0, 1000]);
  const [selectedRating, setSelectedRating] = useState([0, 5]);

  const toggleWishlist = async (book) => {
    try {
      if (wishlist.has(book.id)) {
        // Remove from wishlist
        const response = await fetch(`https://localhost:7045/api/wishlist/${book.id}`, { method: "DELETE" });
  
        if (!response.ok) {
          throw new Error("Failed to remove from wishlist");
        }
  
        setWishlist((prevWishlist) => {
          const newWishlist = new Set(prevWishlist);
          newWishlist.delete(book.id);
          return newWishlist;
        });
  
        alert("Book removed from Wishlist!");
      } else {
        // Add to wishlist
        const response = await fetch("https://localhost:7045/api/wishlist", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(book),
        });
  
        if (!response.ok) {
          throw new Error("Failed to add to wishlist");
        }
  
        setWishlist((prevWishlist) => new Set([...prevWishlist, book.id]));
  
        alert("Book added to Wishlist!");
      }
    } catch (error) {
      console.error("Error updating wishlist:", error);
      alert("Something went wrong. Please try again.");
    }
  };
  
  const addToCart = async (book) => {
    try {
      const response = await fetch("http://localhost:7045/api/cart", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(book),
      });
      if (response.ok) {
        alert("Book added to Cart!");
      } else {
        alert("Failed to add to Cart.");
      }
    } catch (error) {
      console.error("Error adding to cart:", error);
    }
  };

  useEffect(() => {
  fetch("https://localhost:7045/api/Books")
    .then((response) => response.json())
    .then((data) => {
      console.log("Fetched Books:", data);
      setBooks(data);
    })
    .catch((error) => console.error("Error fetching books:", error));
}, []);


  const handleSearch = (event) => {
    setSearchTerm(event.target.value.toLowerCase());
  };

  // Filter books dynamically based on search term and filters
  const displayedBooks = books.filter((book) => {
    const isMatchingSearch =
      book.title.toLowerCase().includes(searchTerm) ||
      book.author.toLowerCase().includes(searchTerm);

    const isMatchingAuthor = selectedAuthors.length
      ? selectedAuthors.includes(book.author)
      : true;

    const isMatchingGenre = selectedGenres.length
      ? selectedGenres.includes(book.genre)
      : true;

    const isMatchingPrice =
      book.price >= priceRange[0] && book.price <= priceRange[1];

  
    return (
      isMatchingSearch &&
      isMatchingAuthor &&
      isMatchingGenre &&
      isMatchingPrice
    );
  });

  // Handle changing author filters
  const handleAuthorChange = (event) => {
    const author = event.target.name;
    setSelectedAuthors((prev) =>
      prev.includes(author)
        ? prev.filter((item) => item !== author)
        : [...prev, author]
    );
  };

  // Handle changing genre filters
  const handleGenreChange = (event) => {
    const genre = event.target.name;
    setSelectedGenres((prev) =>
      prev.includes(genre)
        ? prev.filter((item) => item !== genre)
        : [...prev, genre]
    );
  };

  // Handle price range slider change
  const handlePriceRangeChange = (event, newValue) => {
    setPriceRange(newValue);
  };


  const authorsList = [...new Set(books.map((book) => book.author))];
  const genresList = [...new Set(books.map((book) => book.genre))];

  const [open, setOpen] = useState(false);
  const [genresOpen, setGenresOpen] = useState(false);


  return (
    <Container sx={{ marginTop: "20px" }}>
      <Grid container spacing={3}>
        {/* Left Column - Filters */}
        <Grid item xs={12} md={3} sx={{ paddingRight: "20px" }}>
          <Box sx={{ position: "sticky", top: "20px" }}>
            <Typography variant="h6" fontWeight="bold">
              Filters
            </Typography>

            {/* Authors Filter */}
            <FormGroup sx={{ mt: 2 }}>
              <Typography
                variant="subtitle1"
                onClick={() => setOpen(!open)}
                sx={{ cursor: "pointer", userSelect: "none" }}
              >
                Authors ▼
              </Typography>
              {open &&
                authorsList.map((author) => (
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={selectedAuthors.includes(author)}
                        onChange={handleAuthorChange}
                        name={author}
                      />
                    }
                    label={author}
                    key={author}
                  />
                ))}
            </FormGroup>

            {/* Genres Filter */}
            <FormGroup sx={{ mt: 2 }}>
            <Typography
              variant="subtitle1"
              onClick={() => setGenresOpen(!genresOpen)}
              sx={{ cursor: "pointer", userSelect: "none" }}
            >
              Genres ▼
            </Typography>
            {genresOpen &&
              genresList.map((genre) => (
                <FormControlLabel
                  control={
                    <Checkbox
                      checked={selectedGenres.includes(genre)}
                      onChange={handleGenreChange}
                      name={genre}
                    />
                  }
                  label={genre}
                  key={genre}
                />
              ))}
          </FormGroup>

            {/* Price Range Filter */}
            <Box sx={{ mt: 2 }}>
              <Typography variant="subtitle1">Price Range</Typography>
              <Slider
                value={priceRange}
                onChange={handlePriceRangeChange}
                valueLabelDisplay="auto"
                min={0}
                max={1000}
                valueLabelFormat={(value) => `Rs. ${value}`}
              />
            </Box>
          </Box>
        </Grid>

        {/* Right Column - Books */}
        <Grid item xs={12} md={9}>
          <Grid container spacing={3}>
            {displayedBooks.map((book) => (
              <Grid item xs={12} sm={6} md={4} key={book.id}>
                <Card
                  sx={{
                    height: 350,
                    width: 200,
                    borderRadius: "5px",
                    boxShadow: 4,
                    transition: "0.3s",
                    "&:hover": { transform: "scale(1.05)" },
                  }}
                >
                  <CardMedia component="img" height="170" image={book.img} alt={book.title} />
                  <CardContent sx={{ textAlign: "center" }}>
                    <Typography variant="h7" fontWeight="bold" fontFamily="cursive">
                      {book.title}
                    </Typography>
                    <Typography variant="body2" fontStyle="italic" fontFamily="unset">
                      {book.author}
                    </Typography>
                    <Typography variant="h8" fontWeight="bold">
                      Rs. {book.price}
                    </Typography>
                    <Link to={`/books/${book.id}`} style={{ textDecoration: "none", color: "inherit" }}>
                      <Typography variant="body2" sx={{ mt: 1, color: "black", backgroundColor: "#FFB733" }}>
                        View Details
                      </Typography>
                    </Link>

                    <Box sx={{ display: "flex", justifyContent: "center", gap: 2, mt: 2 }}>
                      {/* Wishlist Icon */}
                      <IconButton onClick={() => toggleWishlist(book)} sx={{ color: wishlist.has(book.id) ? "red" : "inherit" }}>
                        {wishlist.has(book.id) ? <Favorite /> : <FavoriteBorder />}
                      </IconButton>

                      {/* Add to Cart Button */}
                      <Button
                        onClick={() => addToCart(book)}
                        sx={{
                          color: "#E04C16", // Solid orange color
                          fontWeight: "bold",
                          textTransform: "none",
                          "&:hover": {
                            backgroundColor: "transparent", // Remove background change on hover
                            boxShadow: "none", // Remove box-shadow on hover
                          },
                        }}
                      >
                        Add to Cart
                      </Button>
                    </Box>
                  </CardContent>
                </Card>
              </Grid>
            ))}
          </Grid>
        </Grid>
      </Grid>
    </Container>
  );
};

export default Books;
