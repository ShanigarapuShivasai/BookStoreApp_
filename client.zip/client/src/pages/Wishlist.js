import React, { useEffect, useState } from "react";
import { Container, Typography, Grid, Card, CardMedia, CardContent, CardActions, Button } from "@mui/material";
import axios from "axios";

const Wishlist = () => {
  const [wishlist, setWishlist] = useState([]);

  useEffect(() => {
    fetchWishlist();
  }, []);

  const fetchWishlist = async () => {
    try {
      const response = await axios.get("https://localhost:7045/api/wishlist"); // ✅ Update with your API URL
      setWishlist(response.data);
    } catch (error) {
      console.error("Error fetching wishlist:", error);
    }
  };

  const handleRemoveFromWishlist = async (bookId) => {
    try {
      await axios.delete(`https://localhost:7045/api/wishlist/${bookId}`);
      setWishlist(wishlist.filter((book) => book.id !== bookId));
    } catch (error) {
      console.error("Error removing book:", error);
    }
  };

  return (
    <Container sx={{ marginTop: "20px" }}>
      <Typography variant="h4" gutterBottom>
        Wishlist
      </Typography>
      {wishlist.length === 0 ? (
        <Typography variant="body1">Your wishlist is empty.</Typography>
      ) : (
        <Grid container spacing={2}>
          {wishlist.map((book) => (
            <Grid item xs={12} sm={6} md={4} key={book.id}>
              <Card sx={{ maxWidth: 200 }}>
                <CardMedia component="img" height="140" image={book.img} alt={book.title} />
                <CardContent>
                  <Typography variant="h6">{book.title}</Typography>
                  <Typography variant="body2" color="text.secondary">
                    ${book.price}
                  </Typography>
                </CardContent>
                <CardActions>
                  <Button
                    size="small"
                    color="error"
                    onClick={() => handleRemoveFromWishlist(book.id)}
                  >
                    Remove
                  </Button>
                </CardActions>
              </Card>
            </Grid>
          ))}
        </Grid>
      )}
    </Container>
  );
};

export default Wishlist;
