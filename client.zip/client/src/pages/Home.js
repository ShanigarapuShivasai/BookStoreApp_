import React, { useState } from "react";
import { Container, Typography, Button, Box, Card, CardMedia, CardContent, Grid, Link } from "@mui/material";
import { useNavigate } from "react-router-dom";
import SearchBar from "../components/SearchBar";
import Footer from "../components/Footer";

// Sample Data
const trendingBooks = [
  {
    id: 8,
    title: "The Alchemist",
    imageUrl: "https://www.madrasshoppe.com/24981-large_default/the-alchemist-pandit.jpg"
  },
  {
    id: 9,
    title: "Atomic Habits",
    imageUrl: "https://www.madrasshoppe.com/207355-large_default/atomic-habits-james-clear.jpg"
  },
  {
    id: 10,
    title: "Pride and Prejudice",
    imageUrl: "https://m.media-amazon.com/images/I/712P0p5cXIL._AC_UF1000,1000_QL80_.jpg"
  },
  {
    id: 11,
    title: "To Kill a Mockingbird",
    imageUrl: "https://thefirstedition-prod.s3.us-east-2.amazonaws.com/wp-content/uploads/2023/06/15173635/Lee-Harper_To-Kill-A-Mockingbird_14085-3.jpg"
  },
  {
    id: 12,
    title: "The Great Gatsby",
    imageUrl: "https://rekhtabooks.com/cdn/shop/files/9789390183524.jpg?v=1688453070"
  },
];


const genres = [
  { id: 1, name: "Fiction", imageUrl: "https://via.placeholder.com/150" },
  { id: 2, name: "Self-Help", imageUrl: "https://via.placeholder.com/150" },
  { id: 3, name: "Finance", imageUrl: "https://via.placeholder.com/150" },
  { id: 4, name: "Psychology", imageUrl: "https://via.placeholder.com/150" },
  { id: 5, name: "Science Fiction", imageUrl: "https://via.placeholder.com/150" },
];

const HomePage = () => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState(""); // Added missing state

  const cardStyles = { width: 200, height: 270, display: "flex", flexDirection: "column", justifyContent: "space-between" };

  return (
    <Container maxWidth="lg" sx={{ textAlign: "center", marginTop: "50px" }}>
      <Typography variant="h4" sx={{ fontWeight: "bold", fontFamily: "Helvetica", color: "#333" }}>
        Welcome to BookVerse.co
      </Typography>
      <Typography variant="body1" sx={{ fontFamily: "Helvetica", color: "#666", marginTop: "10px" }}>
        Discover a vast collection of books across different genres. Browse, explore, and shop your favorite books online.
      </Typography>
      <Box 
  sx={{ 
    display: "flex", 
    justifyContent: "center", 
    alignItems: "center", 
    width: "100%", 
    marginTop: "30px" 
  }}
>
  <SearchBar searchQuery={searchQuery} setSearchQuery={setSearchQuery} />
</Box>

      <Box sx={{ marginTop: "30px", display: "flex", justifyContent: "center", gap: 2 }}>
        <Button variant="contained" onClick={() => navigate("/books")} sx={{ backgroundColor: "#222", color: "#fff" }}>
          Browse Books
        </Button>
        <Button variant="outlined" onClick={() => navigate("/cart")} sx={{ borderColor: "#222", color: "#222" }}>
          View Cart
        </Button>
      </Box>

      {[{ title: "Trending Books", data: trendingBooks } ].map((section, index) => (
        <Box key={index} sx={{ marginTop: "40px", textAlign: "left" }}>
          <Typography variant="h5" sx={{ fontWeight: "bold", fontFamily: "Helvetica", color: "#333", marginBottom: 2 }}>
            {section.title}
          </Typography>
          <Grid container spacing={2}>
            {section.data.map((item) => (
              <Grid item xs={12} sm={6} md={2.4} key={item.id}>
                <Card onClick={() => navigate(`/${section.title.split(' ')[1].toLowerCase()}/${item.id}`)} sx={{ cursor: "pointer", ...cardStyles }}>
                  <CardMedia component="img" height="140" image={item.imageUrl} alt={item.title || item.name} />
                  <CardContent sx={{ textAlign: "center", fontFamily: "Helvetica" }}>
                    <Typography variant="body1" sx={{ fontWeight: "bold", fontFamily: "Helvetica" }}>
                      {item.title || item.name}
                    </Typography>
                  </CardContent>
                </Card>
              </Grid>
            ))}
          </Grid>
        </Box>
      ))}
      <Footer />

    </Container>

  );
};

export default HomePage;
