import React from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import Books from "./pages/Books";
import NewArrivals from "./pages/NewArrivals";
import Wishlist from "./pages/Wishlist";
import CartPage from "./pages/CartPage";
import Auth from "./components/Auth";
import BookDetails from "./pages/BookDetails";
import AdminDashboard from "./pages/AdminDashboard";
import UserDashboard from "./pages/UserDashboard";
import AddBook from "./pages/AddBook";
import EditBook from "./pages/EditBook";
import DeleteBook from "./pages/DeleteBook";
import { CartProvider } from "./context/CartContext";

const ProtectedRoute = ({ children, allowedRoles }) => {
  const role = localStorage.getItem("role");
  
  if (!role || !allowedRoles.includes(role)) {
    return <Navigate to="/auth" replace />;
  }

  return children;
};

const App = () => {
  const role = localStorage.getItem("role");

  return (
    <CartProvider>
      <Router>
        {/* Show Navbar only for Users */}
        {role !== "Admin" && <Navbar />}

        <Routes>
          {/* Public Route */}
          <Route path="/auth" element={<Auth />} />

          {/* User Routes (Protected) */}
          <Route
            path="/"
            element={
              <ProtectedRoute allowedRoles={["User"]}>
                <Home />
              </ProtectedRoute>
            }
          />
          <Route
            path="/books"
            element={
              <ProtectedRoute allowedRoles={["User"]}>
                <Books />
              </ProtectedRoute>
            }
          />
          <Route
            path="/books/:id"
            element={
              <ProtectedRoute allowedRoles={["User"]}>
                <BookDetails />
              </ProtectedRoute>
            }
          />
          <Route
            path="/new-arrivals"
            element={
              <ProtectedRoute allowedRoles={["User"]}>
                <NewArrivals />
              </ProtectedRoute>
            }
          />
          <Route
            path="/wishlist"
            element={
              <ProtectedRoute allowedRoles={["User"]}>
                <Wishlist />
              </ProtectedRoute>
            }
          />
          <Route
            path="/cart"
            element={
              <ProtectedRoute allowedRoles={["User"]}>
                <CartPage />
              </ProtectedRoute>
            }
          />
          <Route
            path="/user-dashboard"
            element={
              <ProtectedRoute allowedRoles={["User"]}>
                <UserDashboard />
              </ProtectedRoute>
            }
          />

          {/* Admin Routes (Protected) */}
          <Route
            path="/admin-dashboard"
            element={
              <ProtectedRoute allowedRoles={["Admin"]}>
                <AdminDashboard />
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/add-book"
            element={
              <ProtectedRoute allowedRoles={["Admin"]}>
                <AddBook />
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/edit-book/:id"
            element={
              <ProtectedRoute allowedRoles={["Admin"]}>
                <EditBook />
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/delete-book/:id"
            element={
              <ProtectedRoute allowedRoles={["Admin"]}>
                <DeleteBook />
              </ProtectedRoute>
            }
          />

          {/* Fallback: Redirect based on role */}
          <Route path="*" element={<Navigate to={role === "Admin" ? "/admin-dashboard" : "/"} replace />} />
        </Routes>
      </Router>
    </CartProvider>
  );
};

export default App;
