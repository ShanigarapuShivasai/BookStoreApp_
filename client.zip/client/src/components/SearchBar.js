import React, { useState, useEffect } from "react";
import { 
  TextField, InputAdornment, IconButton, Paper, List, ListItem, ListItemText, Box, Typography 
} from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";

const SearchBar = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [suggestions, setSuggestions] = useState([]);
  const [searchResults, setSearchResults] = useState([]);
  const [booksData, setBooksData] = useState([]);
  const [error, setError] = useState(null);

  // Fetch books data from backend API
  useEffect(() => {
    const fetchBooks = async () => {
      try {
        const response = await fetch("https://localhost:7045/api/Books");
        if (!response.ok) throw new Error("Failed to fetch books");
        const data = await response.json();
        setBooksData(data);
      } catch (error) {
        setError(error.message);
      }
    };

    fetchBooks();
  }, []);

  const handleSearchChange = (event) => {
    const value = event.target.value;
    setSearchTerm(value);

    if (value.length > 1) {
      const filteredSuggestions = booksData.filter(
        (item) =>
          item.title.toLowerCase().includes(value.toLowerCase()) ||
          item.author.toLowerCase().includes(value.toLowerCase())
      );
      setSuggestions(filteredSuggestions);
    } else {
      setSuggestions([]);
    }
  };

  const handleSuggestionClick = (suggestion) => {
    setSearchTerm(suggestion.title);
    setSuggestions([]);
    setSearchResults([suggestion]);
  };

  const handleSearchClick = async () => {
    if (searchTerm.trim() !== "") {
      try {
        const response = await fetch(`https://localhost:7045/api/Books/search?query=${encodeURIComponent(searchTerm)}`);

        if (!response.ok) throw new Error("Error fetching search results");

        const results = await response.json();
        setSearchResults(results);
        setSuggestions([]);
      } catch (error) {
        setError(error.message);
      }
    }
  };

  return (
    <Box sx={{ 
        width: "100%", 
        maxWidth: "400px", 
        position: "relative"
      }}>
       <TextField
    label="Search for Books, Authors"
    variant="outlined"
    value={searchTerm}
    onChange={handleSearchChange}
    fullWidth
    sx={{
      backgroundColor: "#fff",
      borderRadius: "5px",
    }}
    InputProps={{
        endAdornment: (
          <InputAdornment position="end">
            <IconButton onClick={handleSearchClick} sx={{ backgroundColor: "#444", color: "#fff", borderRadius: "4px" }}>
              <SearchIcon />
            </IconButton>
          </InputAdornment>
        ),
      }}
    />

      {error && (
        <Typography color="error" sx={{ marginTop: "10px" }}>
          {error}
        </Typography>
      )}

      {suggestions.length > 0 && (
          <Paper sx={{
            position: "absolute",
            top: "100%",   // Places it right below the search bar
            left: 0,
            width: "100%", // Matches the search bar width
            zIndex: 999,   // Ensures it appears on top of other elements
            backgroundColor: "#fff",
            boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.2)",
            maxHeight: "200px",
            overflowY: "auto",
            borderRadius: "4px",
          }}>
          <List>
          {suggestions.map((suggestion) => (
  <ListItem
    button
    key={suggestion.id}
    onClick={() => handleSuggestionClick(suggestion)}
    sx={{
      height: "40px",
      fontFamily: "Arial, sans-serif",
      fontWeight: "bold",
      "&:hover": {
        backgroundColor: "#f0f0f0",
      },
    }}
  >
    <ListItemText
      primaryTypographyProps={{
        fontWeight: "bold",
        fontFamily: "Helvetica",
      }}
      secondaryTypographyProps={{
        fontFamily: "Helvetica",
      }}
      primary={suggestion.title}
      secondary={suggestion.author}
    />
  </ListItem>
))}

          </List>
        </Paper>
      )}

      {searchResults.length > 0 && (
        <Box sx={{ marginTop: "20px" }}>
          <Typography variant="h6">Search Results:</Typography>
          <Box sx={{ display: "flex", justifyContent: "center", flexWrap: "wrap", gap: "15px", marginTop: "10px" }}>
            {searchResults.map((item) => (
              <Paper 
                key={item.id} 
                sx={{ 
                  padding: "10px", 
                  backgroundColor: "#fff", 
                  width: "220px", 
                  textAlign: "center", 
                  boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.2)",
                  borderRadius: "8px"
                }}
              >
                <img 
                  src={item.img} 
                  alt={item.title} 
                  style={{ width: "100%", height: "auto", borderRadius: "5px" }} 
                />
                <Typography variant="subtitle1" sx={{ marginTop: "10px", fontWeight: "bold" }}>
                  {item.title}
                </Typography>
                <Typography variant="body2" sx={{ color: "#666" }}>
                  By {item.author}
                </Typography>
                <Typography variant="body2" sx={{ color: "#333", fontWeight: "bold", marginTop: "5px" }}>
                  ₹{item.price}
                </Typography>
              </Paper>
            ))}
          </Box>
        </Box>
      )}
    </Box>
  );
};

export default SearchBar;
