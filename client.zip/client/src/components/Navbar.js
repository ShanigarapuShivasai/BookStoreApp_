import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { 
  AppBar, Toolbar, Typography, Button, Box, IconButton, Menu, MenuItem 
} from "@mui/material";
import MoreVertIcon from "@mui/icons-material/MoreVert";

const Navbar = () => {
  const [anchorEl, setAnchorEl] = useState(null);
  const [userRole, setUserRole] = useState(null);
  const navigate = useNavigate();

  // Check if the user is logged in
  useEffect(() => {
    const storedRole = localStorage.getItem("role");
    if (storedRole) {
      setUserRole(storedRole);
    }
  }, []);

  
  // Handle Menu Open/Close
  const handleMenuOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  const handleAuthClick = () => {
    navigate("/auth");
  };

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("role");
    setUserRole(null);
  };

  return (
    <AppBar position="static" sx={{ backgroundColor: "#222", boxShadow: "none", padding: "8px 0" }}>
      <Toolbar sx={{ display: "flex", justifyContent: "space-between" }}>
        {/* Branding */}
        <Box component={Link} to="/">
          <Box component="img" 
            src="/assets/logo.png"  
            sx={{ height: 40, width: "10", flex: 0.2 }} 
          />
        </Box>
  
        {/* Navigation */}
        <Box sx={{ flex: 1, display: "flex", justifyContent: "flex-end" }}>
          <Button color="inherit" component={Link} to="/">Home</Button>
          <Button color="inherit" component={Link} to="/books">Books</Button>
          <Button color="inherit" component={Link} to="/wishlist">Wishlist</Button>
          <Button color="inherit" component={Link} to="/cart">Cart</Button>

          {/* Show Logout if user is logged in, otherwise show Login */}
          {userRole ? (
            <>
              {userRole === "Admin" && (
                <Button color="inherit" component={Link} to="/admin-dashboard">Admin Dashboard</Button>
              )}
              <Button color="inherit" onClick={handleLogout}>Logout</Button>
            </>
          ) : (
            <Button color="inherit" onClick={handleAuthClick}>Login</Button>
          )}

          {/* More Options Menu */}
          <IconButton color="inherit" onClick={handleMenuOpen}>
            <MoreVertIcon />
          </IconButton>
          <Menu anchorEl={anchorEl} open={Boolean(anchorEl)} onClose={handleMenuClose}>
            <MenuItem onClick={handleMenuClose} component={Link} to="/best-sellers">Best Sellers</MenuItem>
            <MenuItem onClick={handleMenuClose} component={Link} to="/offers">Offers & Discounts</MenuItem>
            <MenuItem onClick={handleMenuClose} component={Link} to="/categories">New Arrivals</MenuItem>
          </Menu>
        </Box>
      </Toolbar>
    </AppBar>
  );
};

export default Navbar;
