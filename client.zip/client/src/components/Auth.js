import React, { useState } from "react";
import { TextField, Button, Container, Typography, Paper, Tabs, Tab } from "@mui/material";
import { useNavigate } from "react-router-dom";
import axios from "axios";

import { jwtDecode } from "jwt-decode"; // Use named import


const Auth = () => {
    const [tab, setTab] = useState(0); // 0 = Login, 1 = Register
    const [formData, setFormData] = useState({ userName: "", email: "", password: "" });
    const [userRole, setUserRole] = useState(null);
    const navigate = useNavigate();
  
    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };
  
    const handleLogin = async () => {
        try {
          const response = await axios.post("https://localhost:7045/api/Login/Login", {
            userName: formData.userName,
            password: formData.password,
          });
      
          const { token, role } = response.data;
          
          console.log("Token:", token);  // ✅ Debugging token
          console.log("Role:", role);    // ✅ Debugging role
      
          if (token) {
            localStorage.setItem("token", token);
            localStorage.setItem("role", role);
            
            alert(`Login successful! Role: ${role}`);
      
            // ✅ Add a delay to allow storage update
              if (role === "Admin") {
                console.log("Navigating to /admin-dashboard");
                navigate("/admin-dashboard");
              } else {
                console.log("Navigating to /");
                navigate("/");
              }
            }
          else {
            alert("Login failed: Token not received.");
          }
        } catch (error) {
          alert("Login failed: " + (error.response?.data || "Unknown error"));
        }
      };
    const handleRegister = async () => {
        if (!formData.userName || !formData.email || !formData.password) {
            alert("All fields are required.");
            return;
        }

        try {
            await axios.post("https://localhost:7045/api/Login/Register", formData);
            alert("Registration successful! Please login.");
            setTab(0);
        } catch (error) {
            alert("Registration failed: " + (error.response?.data?.message || "Unknown error"));
        }
    };

    const handleLogout = () => {
        setUserRole(null);
        setFormData({ userName: "", email: "", password: "" });
        navigate("/auth");
    };

    return (
        <Container maxWidth="sm">
            <Paper elevation={3} style={{ padding: "20px", marginTop: "50px", textAlign: "center" }}>
                {userRole ? (
                    <>
                        <Typography variant="h5">Welcome, {userRole}!</Typography>
                        <Button
                            variant="contained"
                            color={userRole === "Admin" ? "secondary" : "primary"}
                            href={userRole === "Admin" ? "/admin-dashboard" : "/"}
                        >
                            {userRole === "Admin" ? "Go to Admin Panel" : "Visit Store"}
                        </Button>
                        <Button
                            variant="outlined"
                            color="error"
                            onClick={handleLogout}
                            style={{ marginTop: "10px" }}
                        >
                            Logout
                        </Button>
                    </>
                ) : (
                    <>
                        <Tabs value={tab} onChange={(e, newValue) => setTab(newValue)} centered>
                            <Tab label="Login" />
                            <Tab label="Register" />
                        </Tabs>
                        {tab === 0 ? (
                            <>
                                <TextField fullWidth margin="normal" label="Username" name="userName" onChange={handleChange} />
                                <TextField fullWidth margin="normal" type="password" label="Password" name="password" onChange={handleChange} />
                                <Button fullWidth variant="contained" color="primary" onClick={handleLogin}>
                                    Login
                                </Button>
                            </>
                        ) : (
                            <>
                                <TextField fullWidth margin="normal" label="Username" name="userName" onChange={handleChange} />
                                <TextField fullWidth margin="normal" label="Email" name="email" type="email" onChange={handleChange} />
                                <TextField fullWidth margin="normal" type="password" label="Password" name="password" onChange={handleChange} />
                                <Button fullWidth variant="contained" color="secondary" onClick={handleRegister}>
                                    Register
                                </Button>
                            </>
                        )}
                    </>
                )}
            </Paper>
        </Container>
        
    );
};

export default Auth;
