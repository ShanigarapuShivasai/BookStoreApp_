import React from "react";
import { Box, Typography, Link } from "@mui/material";
import { Facebook, Instagram, YouTube } from "@mui/icons-material";

const Footer = () => {
  return (
    <Box sx={{ marginTop: "50px", padding: "20px", backgroundColor: "#222", color: "#fff", textAlign: "center" }}>
      {/* Social Media Links */}
      <Typography variant="h6" sx={{ fontFamily: "Helvetica" }}>Follow Us</Typography>
      <Box sx={{ display: "flex", justifyContent: "center", gap: 3, marginTop: 1 }}>
        {[{ icon: <Facebook />, link: "https://www.facebook.com" }, 
          { icon: <Instagram />, link: "https://www.instagram.com" }, 
          { icon: <YouTube />, link: "https://www.youtube.com" }].map((social, idx) => (
          <Link key={idx} href={social.link} target="_blank" rel="noopener noreferrer">
            {React.cloneElement(social.icon, { sx: { fontSize: 30, color: "#fff" } })}
          </Link>
        ))}
      </Box>

      {/* Navigation Links */}
      <Box sx={{ marginTop: "20px", display: "flex", justifyContent: "center", gap: 3 }}>
        <Link href="/about" sx={{ color: "#fff", textDecoration: "none", fontSize: "14px" }}>About Us</Link>
        <Link href="/privacy-policy" sx={{ color: "#fff", textDecoration: "none", fontSize: "14px" }}>Privacy Policy</Link>
        <Link href="/terms" sx={{ color: "#fff", textDecoration: "none", fontSize: "14px" }}>Terms & Conditions</Link>
        <Link href="/contact" sx={{ color: "#fff", textDecoration: "none", fontSize: "14px" }}>Contact Us</Link>
      </Box>

      {/* Copyright */}
      <Typography variant="body2" sx={{ marginTop: "10px", fontFamily: "Helvetica" }}>
        &copy; {new Date().getFullYear()} BookVerse.co . All rights reserved.
      </Typography>
    </Box>
  );
};

export default Footer;
